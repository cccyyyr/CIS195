//
//  ViewController.swift
//  app0_chen_cathy
//
//  Created by Cathy Chen on 2020/9/11.
//  Copyright © 2020 Cathy Chen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var myButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        myButton.setTitle("Turn Blue", for:.normal)
        // Do any additional setup after loading the view.
    }


    @IBAction func changeText(_ sender: UIButton) {
        myLabel.text = "Blue"
        myLabel.textColor = myLabel.textColor
    }
}

